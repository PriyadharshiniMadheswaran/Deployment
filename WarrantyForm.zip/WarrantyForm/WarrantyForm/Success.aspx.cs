﻿using System;
using System.Web;

namespace WarrantyForm
{
    public partial class Success : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetExpires(DateTime.UtcNow.AddHours(-1));
            Response.Cache.SetNoStore();
            Response.AppendHeader("cache-control", "no-store");
            Response.AppendHeader("cache-control", "no-cache");   
        }
    }
}