﻿using System;
using System.Data;
using System.Net.Mail;
using System.Text.RegularExpressions;
using System.IO;
using System.Configuration;
using System.Web;

namespace WarrantyForm
{
    public partial class WarrantyForm : System.Web.UI.Page
    {
        /// <summary>
        /// Page Load Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetExpires(DateTime.UtcNow.AddHours(-1));
            Response.Cache.SetNoStore();
            Response.AppendHeader("cache-control", "no-store");
            Response.AppendHeader("cache-control", "no-cache");   
            if (!IsPostBack)
            {
              
                ClearForm();
               
            }
        }
      
        /// <summary>
        /// To reset submitted values in the UI after successful submission
        /// </summary>
        private void ClearForm()
        {
            txtDate.Text = "";
            txtJobSite.Text = "";
            txtName.Text = "";
            txtUnit.Text = "";
            txtBlower.Text = "";
            txtSerial.Text = "";
            txtSales.Text = "";
            txtCount.Text = "";
            txtPoint.Text = "";
            txtHours.Text = "";
            txtRep.Text = "";
            txtReq.Text = "";
            txtPurchase.Text = "";
            txtContactCompany.Text = "";
            txtContactName.Text = "";
            txtAddressLine1.Text = "";
            txtAddressLine2.Text = "";
            txtState.Text = "";
            txtCity.Text = "";
            txtZip.Text = "";
            txtEmail.Text = "";
            txtPhone.Text = "";
            txtExplanation.Text = "";
            txtTicket.Text = "";
            rdShipping.SelectedIndex = -1;
            rdTechnicalServices.SelectedIndex = -1;
            txtRequestedShipDate.Text = "";
            txtQty1.Text = "";
            txtPart1.Text = "";
            txtDescription1.Text = "";
            txtListPrice1.Text = "";
            txtQty2.Text = "";
            txtPart2.Text = "";
            txtDescription2.Text = "";
            txtListPrice2.Text = "";
            txtQty3.Text = "";
            txtPart3.Text = "";
            txtDescription3.Text = "";
            txtListPrice3.Text = "";
            txtQty4.Text = "";
            txtPart4.Text = "";
            txtDescription4.Text = "";
            txtListPrice4.Text = "";
            txtQty5.Text = "";
            txtPart5.Text = "";
            txtDescription5.Text = "";
            txtListPrice5.Text = "";
            txtQty6.Text = "";
            txtPart6.Text = "";
            txtDescription6.Text = "";
            txtListPrice6.Text = "";
            txtQty7.Text = "";
            txtPart7.Text = "";
            txtDescription7.Text = "";
            txtListPrice7.Text = "";
         
        }

        /// <summary>
        /// Field validations are kept in java script, it is to ensure no wrong data 
        /// goes to the submission
        /// </summary>
        private bool IsValidData()
        {
            lblError.Text = hdnError.Value.ToString();
            string Error = "";

            if (txtDate.Text.ToString() == "")
            {

                Error = "Date";

            }
            if (txtJobSite.Text.ToString() == "")
            {
                if (Error == "")
                {
                    Error = "JobSite";
                }
                else
                {
                    Error += " , ";
                    Error += "JobSite";
                }


            }
            if (txtName.Text.ToString() == "")
            {
                if (Error == "")
                {
                    Error = "Name";
                }
                else
                {
                    Error += " , ";
                    Error += "Name";
                }


            }
            if (txtUnit.Text.ToString() == "")
            {
                if (Error == "")
                {
                    Error = "Unit Serial#";
                }
                else
                {
                    Error += " , ";
                    Error += "Unit Serial#";
                }

            }
            if (txtSales.Text.ToString() == "")
            {

                if (Error == "")
                {
                    Error = "Orig. Sales Order";
                }
                else
                {
                    Error += " , ";
                    Error += "Orig. Sales Order";
                }

            }
            if (txtRep.Text.ToString() == "")
            {

                if (Error == "")
                {
                    Error = "Rep Organization";
                }
                else
                {
                    Error += " , ";
                    Error += "Rep Organization";
                }

            }
            if (txtReq.Text.ToString() == "")
            {

                if (Error == "")
                {
                    Error = "Requested by";
                }
                else
                {
                    Error += " , ";
                    Error += "Requested by";
                }

            }
            if (txtPurchase.Text.ToString() == "")
            {

                if (Error == "")
                {
                    Error = "Purchase Order#";
                }
                else
                {
                    Error += " , ";
                    Error += "Purchase Order#";
                }


            }
            if (txtContactCompany.Text.ToString() == "")
            {

                if (Error == "")
                {
                    Error = "Contact Company";
                }
                else
                {
                    Error += " , ";
                    Error += "Contact Company";
                }
            }


           
            if (txtAddressLine1.Text.ToString() == "")
            {

                if (Error == "")
                {
                    Error = "Address Line1";
                }
                else
                {
                    Error += " , ";
                    Error += "Address Line1";
                }

            }

            if (txtCity.Text.ToString() == "")
            {

                if (Error == "")
                {
                    Error = "City";
                }
                else
                {
                    Error += " , ";
                    Error += "City";
                }

            }
            if (txtState.Text.ToString() == "")
            {
                if (Error == "")
                {
                    Error = "State";
                }
                else
                {
                    Error += " , ";
                    Error += "State";
                }

            }

            if (txtZip.Text.ToString() == "")
            {
                if (Error == "")
                {
                    Error = "Zip";
                }
                else
                {
                    Error += " , ";
                    Error += "zip";
                }

            }
            if (txtContactName.Text.ToString() == "")
            {
                if (Error == "")
                {
                    Error = "ContactName";
                }
                else
                {
                    Error += " , ";
                    Error += "ContactName";
                }

            }
            if (txtPhone.Text.ToString() == "")
            {
                if (Error == "")
                {
                    Error = "Phone";
                }
                else
                {
                    Error += " , ";
                    Error += "Phone";
                }

            }
            if (txtEmail.Text.ToString() == "")
            {
                if (Error == "")
                {
                    Error = "E-Mail Address";
                }
                else
                {
                    Error += " , ";
                    Error += "E-Mail Address";
                }

            }
            if (txtExplanation.Text.ToString() == "")
            {

                if (Error == "")
                {
                    Error = "Explanation of Problem";
                }
                else
                {
                    Error += " , ";
                    Error += "Explanation of Problem";
                }

            }
            if (rdTechnicalServices.SelectedIndex < 0)
            {
                if (Error == "")
                {
                    Error = "Technical Services Assist with TroubleShooting";
                }
                else
                {
                    Error += " , ";
                    Error += "Technical Services Assist with TroubleShooting";
                }
            }


            if (txtTicket.Text.ToString() == "")
            {

                if (Error == "")
                {
                    Error = "Reference Ticket Number";
                }
                else
                {
                    Error += " , ";
                    Error += "Reference Ticket Number";
                }

            }
            int errorCount = 0;
            bool isPartValid = false;
            if ((txtQty1.Text.ToString() != "" && txtPart1.Text.ToString() != "" && txtDescription1.Text.ToString() != "" && txtListPrice1.Text.ToString() != "") ||
         (txtQty2.Text.ToString() != "" && txtPart2.Text.ToString() != "" && txtDescription2.Text.ToString() != "" && txtListPrice2.Text.ToString() != "") ||
          (txtQty3.Text.ToString() != "" && txtPart3.Text.ToString() != "" && txtDescription3.Text.ToString() != "" && txtListPrice3.Text.ToString() != "") ||
           (txtQty4.Text.ToString() != "" && txtPart4.Text.ToString() != "" && txtDescription4.Text.ToString() != "" && txtListPrice4.Text.ToString() != "") ||
           (txtQty5.Text.ToString() != "" && txtPart5.Text.ToString() != "" && txtDescription5.Text.ToString() != "" && txtListPrice5.Text.ToString() != "") ||
         (txtQty6.Text.ToString() != "" && txtPart6.Text.ToString() != "" && txtDescription6.Text.ToString() != "" && txtListPrice6.Text.ToString() != "") ||
           (txtQty7.Text.ToString() != "" && txtPart7.Text.ToString() != "" && txtDescription7.Text.ToString() != "" && txtListPrice7.Text.ToString() != "")) { isPartValid = true; }
            else
            {
                isPartValid = false;
            }
          
            if (txtQty1.Text.ToString() != "" || txtPart1.Text.ToString() != "" || txtDescription1.Text.ToString() != "" || txtListPrice1.Text.ToString() != "")
            {
                if (txtQty1.Text.ToString() != "" && txtPart1.Text.ToString() != "" && txtDescription1.Text.ToString() != "" && txtListPrice1.Text.ToString() != "")
                {
                }
                else
                {
                    errorCount = 1;
                }
            }
            if (txtQty2.Text.ToString() != "" || txtPart2.Text.ToString() != "" || txtDescription2.Text.ToString() != "" || txtListPrice2.Text.ToString() != "")
            {
                if (txtQty2.Text.ToString() != "" && txtPart2.Text.ToString() != "" && txtDescription2.Text.ToString() != "" && txtListPrice2.Text.ToString() != "")
                {
                }
                else
                {
                    errorCount = 2;
                }
            }
            if (txtQty3.Text.ToString() != "" || txtPart3.Text.ToString() != "" || txtDescription3.Text.ToString() != "" || txtListPrice3.Text.ToString() != "")
            {
                if (txtQty3.Text.ToString() != "" && txtPart3.Text.ToString() != "" && txtDescription3.Text.ToString() != "" && txtListPrice3.Text.ToString() != "")
                {
                }
                else
                {
                    errorCount = 3;
                }
            }
            if (txtQty4.Text.ToString() != "" || txtPart4.Text.ToString() != "" || txtDescription4.Text.ToString() != "" || txtListPrice4.Text.ToString() != "")
            {
                if (txtQty4.Text.ToString() != "" && txtPart4.Text.ToString() != "" && txtDescription4.Text.ToString() != "" && txtListPrice4.Text.ToString() != "")
                {
                }
                else
                {
                    errorCount = 4;
                }
            }
            if (txtQty5.Text.ToString() != "" || txtPart5.Text.ToString() != "" || txtDescription5.Text.ToString() != "" || txtListPrice5.Text.ToString() != "")
            {
                if (txtQty5.Text.ToString() != "" && txtPart5.Text.ToString() != "" && txtDescription5.Text.ToString() != "" && txtListPrice5.Text.ToString() != "")
                {
                }
                else
                {
                    errorCount = 5;
                }
            }

            if (txtQty6.Text.ToString() != "" || txtPart6.Text.ToString() != "" || txtDescription6.Text.ToString() != "" || txtListPrice6.Text.ToString() != "")
            {
                if (txtQty6.Text.ToString() != "" && txtPart6.Text.ToString() != "" && txtDescription6.Text.ToString() != "" && txtListPrice6.Text.ToString() != "")
                {
                }
                else
                {
                    errorCount = 6;
                }
            }
            if (txtQty7.Text.ToString() != "" || txtPart7.Text.ToString() != "" || txtDescription7.Text.ToString() != "" || txtListPrice7.Text.ToString() != "")
            {
                if (txtQty7.Text.ToString() != "" && txtPart7.Text.ToString() != "" && txtDescription7.Text.ToString() != "" && txtListPrice7.Text.ToString() != "")
                {
                }
                else
                {
                    errorCount = 7;
                }
            }
            if(isPartValid == false)
            {
              
                if (Error == "")
                {
                    Error = "Atleat one Part Information is needed";
                }
                else
                {
                    Error += " , ";
                    Error += "Atleat one Part Information is needed";
                }
            }
            if (errorCount > 0)
            {

                if (Error == "")
                {
                    Error = "Please provide all details for the  Part for Row# "+errorCount.ToString()+"";
                }
                else
                {
                    Error += " , ";
                    Error = "Please provide all details for the  Part for Row# " + errorCount.ToString()+"";
                }
            }

            if (txtRequestedShipDate.Text.ToString() == "")
            {


                if (Error == "")
                {
                    Error = "RequestedShipDate";
                }
                else
                {
                    Error += " , ";
                    Error += "RequestedShipDate";
                }

            }
            if (Error == "")
            {
                if (Regex.IsMatch(txtDate.Text, "((0[1-9]|1[0-2])\\/((0|1)[0-9]|2[0-9]|3[0-1])\\/((19|20)\\d\\d))$"))
                {

                }
                else
                {

                    if (Error == "")
                    {
                        Error = "Date should be mm/dd/yyyy format";
                    }

                }
                if (Regex.IsMatch(txtRequestedShipDate.Text, "((0[1-9]|1[0-2])\\/((0|1)[0-9]|2[0-9]|3[0-1])\\/((19|20)\\d\\d))$"))
                {

                }
                else
                {
                    if (Error == "")
                    {
                        Error = "Requested Ship Date should be mm/dd/yyyy format";
                    }
                    else
                    {
                        Error += " , ";
                        Error += "Requested Ship Date should be mm/dd/yyyy format";
                    }
                }
                if (txtPhone.Text.ToString().Length == 14)
                {

                }
                else
                {
                    if (Error == "")
                    {
                        Error = "Invalid Phone Number Format";
                    }
                    else
                    {
                        Error += " , ";
                        Error += "Invalid Phone Number Format";
                    }
                }
            }
            else
            {
                if (errorCount > 0)
                {
                    Error += ".Please Submit the form after entering all the Mandatory fields";
                }
                else
                {
                    Error += " fields are empty.Please Submit the form after entering all the Mandatory fields";
                }


            }

           
            lblError.Text = Error;

            if (Error == "")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        protected void btnSubmit_Click(object sender, EventArgs e)
        {

            if (IsValidData())
            {
                if (ConfigurationManager.AppSettings["LoadDataInDB"].ToUpper() == "Y") { InsertData(); }
                
                SendEmail();
                ClearForm();
                Response.Redirect("~/Success.aspx");
            }

          
        }

        /// <summary>
        /// To Insert Data in the DB
        /// </summary>
        private void InsertData()
        {
            WarrantFormDAL warrantFormDAL = new WarrantFormDAL();
            WarrantFormModel WarrantFormModel = new WarrantFormModel();
            WarrantFormModel.date = Convert.ToDateTime(txtDate.Text);
            WarrantFormModel.JobSite = txtJobSite.Text;
            WarrantFormModel.Name = txtName.Text;
            WarrantFormModel.UnitSerial = txtUnit.Text;
            WarrantFormModel.Blower = txtBlower.Text;
            WarrantFormModel.Serial = txtSerial.Text;
            WarrantFormModel.CycleCount = txtCount.Text;
            WarrantFormModel.SetPoint = txtPoint.Text;
            WarrantFormModel.RunHours = txtHours.Text;
            WarrantFormModel.SalesOrder = Convert.ToInt64(txtSales.Text);
            WarrantFormModel.PurchaseOrder = txtPurchase.Text;
            WarrantFormModel.RequestedBy = txtReq.Text;
            WarrantFormModel.RepOrganisation = txtRep.Text;
            WarrantFormModel.ContactCompany = txtContactCompany.Text;
            WarrantFormModel.ContactName = txtContactName.Text;
            WarrantFormModel.AddressLine1 = txtAddressLine1.Text;
            WarrantFormModel.AddressLine2 = txtAddressLine2.Text;
            WarrantFormModel.City = txtCity.Text;
            WarrantFormModel.State = txtState.Text;
            WarrantFormModel.Zip = txtZip.Text;
            WarrantFormModel.Phone = txtPhone.Text;
            WarrantFormModel.EmailAddress = txtEmail.Text;
            WarrantFormModel.ExplanationOfProblem = txtExplanation.Text;
            WarrantFormModel.TechnicalServices = rdTechnicalServices.SelectedItem.ToString();
            WarrantFormModel.TicketNumber = txtTicket.Text;
            WarrantFormModel.ShippingOptionsValue = rdShipping.SelectedValue.ToString();
          
            if (txtOthers.Text == "" && rdShipping.SelectedValue.ToString() != "")
            {
                WarrantFormModel.ShippingOptionsText = rdShipping.SelectedItem.ToString();
            }
            else
            {
                WarrantFormModel.ShippingOptionsText = txtOthers.Text.ToString();
            }
            WarrantFormModel.RequestedShipDate = Convert.ToDateTime(txtRequestedShipDate.Text);
            int submissionId = 0;
              submissionId = warrantFormDAL.add(WarrantFormModel);
            DataTable dt = new DataTable();
            dt.Columns.AddRange(new DataColumn[5] { new DataColumn("Qty", typeof(long)),
                    new DataColumn("Part", typeof(string)),
                    new DataColumn("[Description]",typeof(string)),new DataColumn("ListPrice", typeof(double)),new DataColumn("SubmissionId", typeof(int)) });
            if (txtQty1.Text.ToString() != "" && txtPart1.Text.ToString() != "" && txtDescription1.Text.ToString() != "" && txtListPrice1.Text.ToString() != "") { dt.Rows.Add(Convert.ToInt64(txtQty1.Text), txtPart1.Text, txtDescription1.Text, Convert.ToDouble(txtListPrice1.Text), submissionId); }
            if (txtQty2.Text.ToString() != "" && txtPart2.Text.ToString() != "" && txtDescription2.Text.ToString() != "" && txtListPrice2.Text.ToString() != "") { dt.Rows.Add(Convert.ToInt64(txtQty2.Text), txtPart2.Text, txtDescription2.Text, Convert.ToDouble(txtListPrice2.Text), submissionId); }
            if (txtQty3.Text.ToString() != "" && txtPart3.Text.ToString() != "" && txtDescription3.Text.ToString() != "" && txtListPrice3.Text.ToString() != "") { dt.Rows.Add(Convert.ToInt64(txtQty3.Text), txtPart3.Text, txtDescription3.Text, Convert.ToDouble(txtListPrice3.Text), submissionId); }
            if (txtQty4.Text.ToString() != "" && txtPart4.Text.ToString() != "" && txtDescription4.Text.ToString() != "" && txtListPrice4.Text.ToString() != "") {dt.Rows.Add(Convert.ToInt64(txtQty4.Text), txtPart4.Text, txtDescription4.Text, Convert.ToDouble(txtListPrice4.Text), submissionId);}
             if (txtQty5.Text.ToString() != "" && txtPart5.Text.ToString() != "" && txtDescription5.Text.ToString() != "" && txtListPrice5.Text.ToString() != ""){dt.Rows.Add(Convert.ToInt64(txtQty5.Text), txtPart5.Text, txtDescription5.Text, Convert.ToDouble(txtListPrice5.Text), submissionId);}
             if (txtQty6.Text.ToString() != "" && txtPart6.Text.ToString() != "" && txtDescription6.Text.ToString() != "" && txtListPrice6.Text.ToString() != ""){dt.Rows.Add(Convert.ToInt64(txtQty6.Text), txtPart6.Text, txtDescription6.Text, Convert.ToDouble(txtListPrice6.Text), submissionId);}
             if (txtQty7.Text.ToString() != "" && txtPart7.Text.ToString() != "" && txtDescription7.Text.ToString() != "" && txtListPrice7.Text.ToString() != ""){dt.Rows.Add(Convert.ToInt64(txtQty7.Text), txtPart7.Text, txtDescription7.Text, Convert.ToDouble(txtListPrice7.Text), submissionId); }
              warrantFormDAL.addQtyDetails(dt);
        }
        
        /// <summary>
        /// To Send Emails
        /// </summary>
        private void SendEmail()
        {
            MailMessage mail = new MailMessage();
            mail.To.Add(ConfigurationManager.AppSettings["RecipientEMailAddress"]);
            mail.From = new MailAddress(ConfigurationManager.AppSettings["SourceEMailAddress"]);
            string body = string.Empty;
            using (StreamReader reader = new StreamReader(Server.MapPath("~/WarrantyForm.htm")))
            {
                body = reader.ReadToEnd();
            }
            body = body.Replace("{Date}", txtDate.Text);
            body = body.Replace("{JobSite}", txtJobSite.Text);
            body = body.Replace("{Name}", txtName.Text);
            body = body.Replace("{Unit}", txtUnit.Text);
            body = body.Replace("{Count}", txtCount.Text);
            body = body.Replace("{Hours}", txtHours.Text);
            body = body.Replace("{Point}", txtPoint.Text);
            body = body.Replace("{Blower}", txtBlower.Text);
            body = body.Replace("{Serial}", txtSerial.Text);
            body = body.Replace("{Blower}", txtBlower.Text);
            body = body.Replace("{Serial}", txtSerial.Text);
            body = body.Replace("{Sales}", txtSales.Text);
            body = body.Replace("{Rep}", txtRep.Text);
            body = body.Replace("{Req}", txtReq.Text);
            body = body.Replace("{Pur}", txtPurchase.Text);
            body = body.Replace("{Company}", txtContactCompany.Text);
            body = body.Replace("{Line1}", txtAddressLine1.Text);
            body = body.Replace("{Line2}", txtAddressLine2.Text);
            body = body.Replace("{City}", txtCity.Text);
            body = body.Replace("{State}", txtState.Text);
            body = body.Replace("{Zip}", txtZip.Text);
            body = body.Replace("{Phone}", txtPhone.Text);
            body = body.Replace("{CName}", txtContactName.Text);
            body = body.Replace("{EMail}", txtEmail.Text);
            body = body.Replace("{Prob}", txtExplanation.Text);
            body = body.Replace("{Ref}", txtTicket.Text);
            body = body.Replace("{Tech}", rdTechnicalServices.SelectedItem.Text);
            if(rdShipping.SelectedValue.ToString() != "")
            {
                body = body.Replace("{shp}", rdShipping.SelectedItem.Text);
            }
            else
            {
                body = body.Replace("{shp}", "");
            }
            body = body.Replace("{txt}", txtOthers.Text);
            body = body.Replace("{shpDate}", txtRequestedShipDate.Text);
            body = body.Replace("{Qty1}", txtQty1.Text);
            body = body.Replace("{Part1}", txtPart1.Text);
            body = body.Replace("{Des1}", txtDescription1.Text);
            body = body.Replace("{List1}", txtListPrice1.Text);
            body = body.Replace("{Qty2}", txtQty2.Text);
            body = body.Replace("{Part2}", txtPart2.Text);
            body = body.Replace("{Des2}", txtDescription2.Text);
            body = body.Replace("{List2}", txtListPrice2.Text);
            body = body.Replace("{Qty3}", txtQty3.Text);
            body = body.Replace("{Part3}", txtPart3.Text);
            body = body.Replace("{Des3}", txtDescription3.Text);
            body = body.Replace("{List3}", txtListPrice3.Text);
            body = body.Replace("{Qty4}", txtQty4.Text);
            body = body.Replace("{Part4}", txtPart4.Text);
            body = body.Replace("{Des4}", txtDescription4.Text);
            body = body.Replace("{List4}", txtListPrice4.Text);
            body = body.Replace("{Qty5}", txtQty5.Text);
            body = body.Replace("{Part5}", txtPart5.Text);
            body = body.Replace("{Des5}", txtDescription5.Text);
            body = body.Replace("{List5}", txtListPrice5.Text);
            body = body.Replace("{Qty6}", txtQty6.Text);
            body = body.Replace("{Part6}", txtPart6.Text);
            body = body.Replace("{Des6}", txtDescription6.Text);
            body = body.Replace("{List6}", txtListPrice6.Text);
            body = body.Replace("{Qty7}", txtQty7.Text);
            body = body.Replace("{Part7}", txtPart7.Text);
            body = body.Replace("{Des7}", txtDescription7.Text);
            body = body.Replace("{List7}", txtListPrice7.Text);

            mail.Subject = ConfigurationManager.AppSettings["EMailSubject"];
            mail.Body = body;
            mail.IsBodyHtml = true;
            SmtpClient smtp = new SmtpClient(ConfigurationManager.AppSettings["SMTPServer"]);

            smtp.UseDefaultCredentials = true;
            smtp.Send(mail);            
        }

        /// <summary>
        /// Shipping option selection change event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void rdShipping_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (rdShipping.SelectedValue.ToString() != "Other")
            {
                txtOthers.Text = "";
            }
        }
    }
}
